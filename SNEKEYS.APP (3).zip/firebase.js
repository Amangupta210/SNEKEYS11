// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-analytics.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  query,
  onSnapshot,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCcw0JFxB0AcUs1b_CXgWOFqi8v_JK3iAs",
  authDomain: "snekeys-love.firebaseapp.com",
  projectId: "snekeys-love",
  storageBucket: "snekeys-love.firebasestorage.app",
  messagingSenderId: "513108946451",
  appId: "1:513108946451:web:f2fa4803733955f84999e6",
  measurementId: "G-WJTNEC30ZP"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const db = getFirestore(app);

export {
  analytics,
  auth,
  db,
  signInAnonymously,
  onAuthStateChanged,
  collection,
  addDoc,
  query,
  onSnapshot,
  orderBy,
  serverTimestamp
};
